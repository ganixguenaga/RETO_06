def create_summary(df):
    return df.describe()